/**
 * Locale-independent identity and contact details.
 * Anything translatable lives in the i18n dictionaries instead.
 */
export const siteConfig = {
  name: "Ahmad Dewedar",
  email: "ahmaddewedar2016@gmail.com",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? vercelProductionUrl() ?? "http://localhost:3000",
} as const;

/** Vercel sets the project's production domain (no protocol) during builds, so canonical URLs never point at localhost. */
function vercelProductionUrl(): string | undefined {
  const host = process.env.VERCEL_PROJECT_PRODUCTION_URL;
  return host ? `https://${host}` : undefined;
}

export const youtubeChannel = {
  handle: "@AhmadDewedar",
  url: "https://www.youtube.com/@AhmadDewedar",
  /** Opens the channel with YouTube's subscribe confirmation. */
  subscribeUrl: "https://www.youtube.com/@AhmadDewedar?sub_confirmation=1",
} as const;

export type SocialId = "github" | "linkedin" | "fiverr" | "youtube";

export interface SocialLink {
  id: SocialId;
  label: string;
  /** Account name as shown on the platform. */
  handle: string;
  href: string;
}

export const socialLinks: readonly SocialLink[] = [
  { id: "github", label: "GitHub", handle: "Ahmad-git-Dewedar", href: "https://github.com/Ahmad-git-Dewedar" },
  { id: "linkedin", label: "LinkedIn", handle: "Ahmad Dewedar", href: "https://www.linkedin.com/in/ahmad-dewedar-706a4339b" },
  { id: "fiverr", label: "Fiverr", handle: "ahmad_dewedar", href: "https://www.fiverr.com/ahmad_dewedar" },
  { id: "youtube", label: "YouTube", handle: "@AhmadDewedar", href: youtubeChannel.url },
];
