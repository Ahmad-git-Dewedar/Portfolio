import type { Locale } from "@/i18n/config";
import { pick, type Localized } from "@/i18n/localized";

export interface ProjectImage {
  /** Path under /public. */
  src: string;
  width: number;
  height: number;
  alt: Localized;
}

/**
 * How a project's cinematic scene enters and leaves.
 * - zoom: the visual grows from a small tilted card, then the camera zooms through it.
 * - slit: a narrow vertical slit opens to full frame; exits into giant typography.
 * - rise: the visual stands up from a 3D tilt; exits behind a sweeping light.
 * - lift: the visual rises through a mask; the whole shot lifts away into the page.
 */
export type SceneVariant = "zoom" | "slit" | "rise" | "lift";

export interface ProjectScene {
  variant: SceneVariant;
  /** Scene background behind the visual. */
  background: string;
  /** Light scenes switch text to dark ink. */
  tone: "dark" | "light";
}

export interface Project {
  slug: string;
  title: Localized;
  category: Localized;
  summary: Localized;
  /** Short feature highlights, listed on the featured card. */
  highlights: Localized<readonly string[]>;
  tags: Localized<readonly string[]>;
  /** Live deployment. */
  href: string;
  image: ProjectImage;
  /** Brand color of the project, used for hover glows and accents. */
  accent: string;
  /** Featured projects get a badge in their scene. */
  featured?: boolean;
  scene: ProjectScene;
}

export const projects: readonly Project[] = [
  {
    slug: "ultimate-xi",
    title: { en: "Ultimate XI", ar: "Ultimate XI" },
    category: { en: "Web game", ar: "لعبة ويب" },
    summary: {
      en: "A football squad-building game in the browser. Open packs, build a chemistry-driven starting XI, trade on the market and play matches against a bot to earn coins and gems.",
      ar: "لعبة كرة قدم لبناء الفريق داخل المتصفح. افتح الحزم، وكوّن تشكيلة أساسية مبنية على الانسجام، وتداول في السوق، والعب مباريات ضد الكمبيوتر لتربح العملات والجواهر.",
    },
    highlights: {
      en: [
        "Pack opening with a free daily pack",
        "Squad builder with team rating and chemistry",
        "Matches against a bot with coin and gem rewards",
        "Player market, collection and level progression",
      ],
      ar: [
        "فتح الحزم مع حزمة مجانية يومية",
        "بناء التشكيلة مع تقييم الفريق والانسجام",
        "مباريات ضد الكمبيوتر بمكافآت من العملات والجواهر",
        "سوق اللاعبين والمجموعة ونظام المستويات",
      ],
    },
    tags: { en: ["Game UI", "Web app", "Dashboard"], ar: ["واجهة لعبة", "تطبيق ويب", "لوحة تحكم"] },
    href: "https://ultimate-xi-1zky.onrender.com",
    image: {
      src: "/projects/ultimate-xi-cover.webp",
      width: 1600,
      height: 893,
      alt: {
        en: "Ultimate XI cover in gold lettering on navy, framed by two blue footballs",
        ar: "غلاف Ultimate XI بخط ذهبي على خلفية كحلية تحيط به كرتا قدم زرقاوان",
      },
    },
    accent: "#ffc72c",
    featured: true,
    scene: { variant: "zoom", background: "#06080d", tone: "dark" },
  },
  {
    slug: "iphone-17-pro-max",
    title: { en: "iPhone 17 Pro Max", ar: "iPhone 17 Pro Max" },
    category: { en: "Product experience", ar: "تجربة منتج" },
    summary: {
      en: "A cinematic product launch page with bold typography and a scroll-driven story across experience, design, performance and camera.",
      ar: "صفحة إطلاق منتج سينمائية بخطوط جريئة وقصة تتكشف مع التمرير عبر التجربة والتصميم والأداء والكاميرا.",
    },
    highlights: {
      en: ["Scroll-driven storytelling", "Editorial, large-scale typography", "English and Arabic versions"],
      ar: ["سرد قصصي يتفاعل مع التمرير", "طباعة تحريرية بأحجام كبيرة", "نسختان بالإنجليزية والعربية"],
    },
    tags: { en: ["Landing page", "Motion", "Bilingual"], ar: ["صفحة هبوط", "حركة", "ثنائية اللغة"] },
    href: "https://iphone17promax-project.netlify.app",
    image: {
      src: "/projects/iphone-17-pro-max-cover.webp",
      width: 1600,
      height: 893,
      alt: {
        en: "iPhone 17 Pro Max cover with glowing orange camera module and phone edge on black",
        ar: "غلاف iPhone 17 Pro Max مع وحدة كاميرا وحافة هاتف برتقالية متوهجة على خلفية سوداء",
      },
    },
    accent: "#ff7a1a",
    scene: { variant: "slit", background: "#0a0706", tone: "dark" },
  },
  {
    slug: "mehmed-ii",
    title: { en: "Mehmed II", ar: "محمد الفاتح" },
    category: { en: "Historical storytelling", ar: "سرد تاريخي" },
    summary: {
      en: "An illustrated life of Sultan Mehmed II, from his birth in Edirne in 1432 to the conquest of Constantinople and a new capital, told in eight cinematic scenes and a detailed visual history.",
      ar: "سيرة مصوّرة للسلطان محمد الثاني، من مولده في إدرنة عام 1432 إلى فتح القسطنطينية وبناء عاصمة جديدة، تُروى في ثمانية مشاهد سينمائية وتاريخ بصري مفصّل.",
    },
    highlights: {
      en: [
        "Seven chapters in framed video scenes with scroll-driven depth",
        "Interactive map of 14 military campaigns",
        "Arabic-first, with an English version and light and dark themes",
        "Vanilla TypeScript and Vite, with a static layout for reduced motion",
      ],
      ar: [
        "سبعة فصول في مشاهد فيديو مؤطّرة بعمق يتفاعل مع التمرير",
        "خريطة تفاعلية لأربع عشرة حملة عسكرية",
        "بالعربية أولًا، مع نسخة إنجليزية ووضعين فاتح وداكن",
        "TypeScript و Vite دون إطار عمل، مع تخطيط ثابت عند تقليل الحركة",
      ],
    },
    tags: { en: ["Storytelling", "Motion", "Bilingual"], ar: ["سرد قصصي", "حركة", "ثنائية اللغة"] },
    href: "https://mehmed-ll.ahmaddewedar2016.workers.dev/",
    image: {
      src: "/projects/mehmed-ii-cover.jpg",
      width: 2000,
      height: 1116,
      alt: {
        en: "Mehmed II cover with the title in gold serif lettering on charcoal, framed by an Ottoman tughra and a mosque dome",
        ar: "غلاف محمد الثاني بعنوان ذهبي على خلفية فحمية، تحيط به طغراء عثمانية وقبة مسجد",
      },
    },
    accent: "#c49a6c",
    scene: { variant: "rise", background: "#0b0a09", tone: "dark" },
  },
  {
    slug: "mizan",
    title: { en: "Mizan", ar: "ميزان" },
    category: { en: "Fintech landing page", ar: "صفحة هبوط مالية" },
    summary: {
      en: "An Arabic-first personal finance product that helps people see their money more clearly, with a calm, focused landing experience.",
      ar: "منتج للإدارة المالية الشخصية مصمم للعربية أولًا، يساعد الناس على رؤية أموالهم بوضوح، بتجربة هبوط هادئة ومركزة.",
    },
    highlights: {
      en: ["Arabic-first, right-to-left design", "Clear calls to action for web and app", "Features, pricing and sign-in flows"],
      ar: ["تصميم للعربية أولًا من اليمين إلى اليسار", "دعوات واضحة لاتخاذ إجراء للويب والتطبيق", "أقسام للمميزات والأسعار وتسجيل الدخول"],
    },
    tags: { en: ["Fintech", "RTL", "Landing page"], ar: ["تقنية مالية", "من اليمين لليسار", "صفحة هبوط"] },
    href: "https://mizan-project.netlify.app",
    image: {
      src: "/projects/mizan-cover.webp",
      width: 1600,
      height: 893,
      alt: {
        en: "Mizan cover in green with a rising chart and a stack of coins",
        ar: "غلاف ميزان باللون الأخضر مع رسم بياني صاعد وكومة عملات",
      },
    },
    accent: "#3ddc97",
    scene: { variant: "lift", background: "#050807", tone: "dark" },
  },
];

/** A project with every localized field resolved, ready to pass to client components. */
export interface ProjectView {
  slug: string;
  title: string;
  category: string;
  summary: string;
  highlights: readonly string[];
  tags: readonly string[];
  href: string;
  /** Host name shown in the browser-frame address bar. */
  domain: string;
  image: { src: string; width: number; height: number; alt: string };
  accent: string;
  featured: boolean;
  scene: ProjectScene;
  /** Background of the scene that follows, so each exit can hand over seamlessly. */
  nextBackground: string | null;
  /** 1-based position, for the "01 / 04" counter. */
  position: number;
}

export function toProjectView(project: Project, locale: Locale, index = 0, list: readonly Project[] = [project]): ProjectView {
  return {
    slug: project.slug,
    title: pick(project.title, locale),
    category: pick(project.category, locale),
    summary: pick(project.summary, locale),
    highlights: pick(project.highlights, locale),
    tags: pick(project.tags, locale),
    href: project.href,
    domain: new URL(project.href).host,
    image: { ...project.image, alt: pick(project.image.alt, locale) },
    accent: project.accent,
    featured: Boolean(project.featured),
    scene: project.scene,
    nextBackground: list[index + 1]?.scene.background ?? null,
    position: index + 1,
  };
}

export function getProjectViews(locale: Locale): ProjectView[] {
  return projects.map((project, index) => toProjectView(project, locale, index, projects));
}
