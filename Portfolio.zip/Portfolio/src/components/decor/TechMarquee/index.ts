export { TechMarquee } from "./TechMarquee";
