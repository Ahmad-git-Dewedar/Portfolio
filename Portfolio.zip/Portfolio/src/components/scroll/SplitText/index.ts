export { SplitText } from "./SplitText";
