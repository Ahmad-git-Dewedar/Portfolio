export { FaqSection } from "./FaqSection";
