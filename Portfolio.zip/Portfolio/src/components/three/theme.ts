/** Scene palette, mirrored from the CSS design tokens so 2D and 3D stay in sync. */
export const sceneTheme = {
  accent: "#2997ff",
  accentAlt: "#94a3b8",
  accentSoft: "#9fd0ff",
  /** Neutral graphite light for halos and floor pools: the stage stays black, not tinted. */
  halo: "#8f959e",
  success: "#30d158",
  aluminium: "#2b2b2f",
  glassTint: "#dcebff",
  glassAttenuation: "#9cc8ff",
  chrome: "#d9dde3",
  screenTop: "#0d1526",
  screenBottom: "#04060b",
} as const;
